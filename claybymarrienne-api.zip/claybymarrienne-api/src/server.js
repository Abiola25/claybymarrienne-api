const express = require('express');
const app = express();
const cartRoutes = require('./routes/cartRoutes');

app.use(express.json());
app.use('/api', cartRoutes);

const PORT = process.env.PORT || 5001;
app.listen(PORT, () => {
  console.log(`Server running on port ${PORT}`);
});
