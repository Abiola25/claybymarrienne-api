let cart = [];

function addToCart(req, res) {
  const { id, name, price, image } = req.body;

  if (!id || !name || !price || !image) {
    return res.status(400).json({ message: 'All product fields are required' });
  }

  const existingItem = cart.find((item) => item.id === id);

  if (existingItem) {
    existingItem.quantity += 1;
    existingItem.subtotal = existingItem.quantity * existingItem.price;
  } else {
    cart.push({
      id,
      name,
      price,
      image,
      quantity: 1,
      subtotal: price,
    });
  }

  res.status(200).json({ message: 'Item added to cart', cart });
}

function getCart(req, res) {
  res.status(200).json(cart);
}

function updateCartItem(req, res) {
  const itemId = req.params.id;
  const { quantity } = req.body;

  const item = cart.find((item) => item.id === itemId);

  if (!item) {
    return res.status(404).json({ message: 'Item not found in cart' });
  }

  item.quantity = quantity;
  item.subtotal = item.quantity * item.price;

  res.status(200).json({ message: 'Cart updated successfully', cart });
}

function deleteCartItem(req, res) {
  const itemId = req.params.id;

  cart = cart.filter((item) => item.id !== itemId);

  res.status(200).json({ message: 'Item removed from cart', cart });
}

function getCartTotal(req, res) {
  const total = cart.reduce((sum, item) => sum + item.subtotal, 0);
  res.status(200).json({ total });
}

function getCartSummary(req, res) {
  const totalItems = cart.reduce((sum, item) => sum + item.quantity, 0);
  const totalPrice = cart.reduce((sum, item) => sum + item.subtotal, 0);
  res.status(200).json({ totalItems, totalPrice });
}

module.exports = {
  addToCart,
  getCart,
  updateCartItem,
  deleteCartItem,
  getCartTotal,
  getCartSummary,
};
