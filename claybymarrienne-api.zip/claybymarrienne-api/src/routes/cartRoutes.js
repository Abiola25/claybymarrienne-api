const express = require('express');
const router = express.Router();
const {
  addToCart,
  getCart,
  updateCartItem,
  deleteCartItem,
  getCartTotal,
  getCartSummary,
} = require('../controllers/cartController');

router.post('/cart', addToCart);
router.get('/cart', getCart);
router.put('/cart/update/:id', updateCartItem);
router.delete('/cart/delete/:id', deleteCartItem);
router.get('/cart/total', getCartTotal);
router.get('/cart/summary', getCartSummary);

module.exports = router;
