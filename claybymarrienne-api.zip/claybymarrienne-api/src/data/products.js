const products = [
  {
    id: 1,
    name: "2L Clay Jugs",
    price: 3000,
    description: "Handmade 2L clay jug.",
    image: "https://res.cloudinary.com/dz3be1jmf/image/upload/v1750356769/2L-clay-jugs.jpg_gt4psy.jpg"
  },
  {
    id: 2,
    name: "Oreke Cup",
    price: 1000,
    description: "Smooth traditional clay cup.",
    image: "https://res.cloudinary.com/dz3be1jmf/image/upload/v1750356768/oreke-cup.jpg_nsmlt9.jpg"
  },
  {
    id: 3,
    name: "2L Clay Cookware",
    price: 3500,
    description: "Perfect for slow cooking.",
    image: "https://res.cloudinary.com/dz3be1jmf/image/upload/v1750356768/2L-clay-cookware_ctvhol.jpg"
  },
  {
    id: 4,
    name: "Raino Alkaline Bottle",
    price: 5000,
    description: "Natural water filtration.",
    image: "https://res.cloudinary.com/dz3be1jmf/image/upload/v1750356768/rainoalkaline-bottle.jpg_otgdte.jpg"
  },
  {
    id: 5,
    name: "6-8L Clay Cookware",
    price: 6000,
    description: "Large family-size pot.",
    image: "https://res.cloudinary.com/dz3be1jmf/image/upload/v1750356767/6-8L-clay-cookware_jikrxx.jpg"
  },
  {
    id: 6,
    name: "Clay Cup",
    price: 800,
    description: "Eco-friendly clay cup.",
    image: "https://res.cloudinary.com/dz3be1jmf/image/upload/v1750356766/clay-cup.jpg_yvflsx.jpg"
  },
  {
    id: 7,
    name: "Clay Alkaline Bottle",
    price: 4800,
    description: "Health-boosting clay bottle.",
    image: "https://res.cloudinary.com/dz3be1jmf/image/upload/v1750356766/clay-alkalinebottle.jpg_xm04qz.jpg"
  },
  {
    id: 8,
    name: "4-6L Clay Cookware",
    price: 4500,
    description: "Medium-sized traditional cookware.",
    image: "https://res.cloudinary.com/dz3be1jmf/image/upload/v1750356766/4-6L-clay-cookware_l3rmay.jpg"
  },
  {
    id: 9,
    name: "Clay Alkaline Dispenser",
    price: 7500,
    description: "Dispenser for clean drinking water.",
    image: "https://res.cloudinary.com/dz3be1jmf/image/upload/v1750356766/clay-alkalin-dispenser.jpg_cwyppc.jpg"
  },
  {
    id: 10,
    name: "Clay Cookware Sets",
    price: 10000,
    description: "Complete set for all cooking needs.",
    image: "https://res.cloudinary.com/dz3be1jmf/image/upload/v1750356766/clay-cookwaresets.jpg_fbj2wn.jpg"
  },
  {
    id: 11,
    name: "Clay Plate",
    price: 1500,
    description: "Traditional handmade plate.",
    image: "https://res.cloudinary.com/dz3be1jmf/image/upload/v1750356767/clay-plate.jpg_n44opz.jpg"
  },
  {
    id: 12,
    name: "Clay Goblet",
    price: 1200,
    description: "Beautifully designed goblet.",
    image: "https://res.cloudinary.com/dz3be1jmf/image/upload/v1750356767/clay-goblet.jpg_jtap61.jpg"
  },
  {
    id: 13,
    name: "Clay Mug",
    price: 1300,
    description: "Classic style clay mug.",
    image: "https://res.cloudinary.com/dz3be1jmf/image/upload/v1750356768/clay-mug.jpg_l4wkem.jpg"
  }
];

module.exports = products;
